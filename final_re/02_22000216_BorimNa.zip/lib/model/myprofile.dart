class MyProfile{
  MyProfile({required this.email, required this.uid});
  final String email;
  final String uid;
}